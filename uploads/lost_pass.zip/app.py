from flask import Flask, request, jsonify, redirect, url_for, render_template
import sqlite3
from sqlite3 import Error
import jwt
from datetime import datetime, timedelta
from functools import wraps
import secrets
import sys
import hashlib
import time

sys.set_int_max_str_digits(0)
app = Flask(__name__)
app.config['SECRET_KEY'] = secrets.token_hex(20)


class DB:

    db = sqlite3.connect("some.db", check_same_thread=False)
    cur = db.cursor()

    def __init__(self):
        create_table = """CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE,
            password TEXT NOT NULL
        );"""
        self.cur.execute(create_table)

    def createUser(self, username, password):
        try:
            self.cur.execute("INSERT INTO users VALUES(?,?,?)",
                             (None, username, password,))
            self.db.commit()
            return self.getUserbyUsername(username)
        except Exception as e:
            print(e)
            return None

    def getUserbyUsername(self, username):
        res = self.cur.execute(
            "SELECT id,username,password FROM users WHERE username=?", (username,))
        user = res.fetchone()
        if user:
            return {
                "id": user[0],
                "username": user[1],
                "password": user[2],
            }
        return None

    def getUserbyId(self, id):
        res = self.cur.execute(
            "SELECT id,username,password FROM users WHERE id=?", (id,))
        user = res.fetchone()
        if user:
            return {
                "id": user[0],
                "username": user[1],
                "password": user[2],
            }
        return None


db = DB()


def auth_required(f):
    @wraps(f)
    def decorator(*args, **kwargs):

        token = None
        if 'authorization' in request.cookies:
            token = request.cookies.get('authorization')

        if not token:
            return jsonify({'message': 'a valid token is missing'})
        try:
            data = jwt.decode(
                token, app.config['SECRET_KEY'], algorithms=["HS256"])
            current_user = db.getUserbyId(data["id"])
        except:
            return jsonify({'message': 'token is invalid'})

        return f(current_user, *args, **kwargs)
    return decorator


def error_log(username, password):
    if username == "admin":
        f = open("error.log", "w")
        time.sleep(1)
        f.write(f"SOMEONE TRIED TO LOGIN AS ADMIN USING {password} !!!1!11!!")
        f.close()
    return False


def check_password(username, hashed_password, password):
    hashed_password = hashed_password.split(",")

    for x in range(len(hashed_password)):
        try:
            if hash_char(password[x]) != hashed_password[x]:
                return error_log(username, password)
        except:
            return False
    return True


def hash_char(char):
    return hashlib.md5(char.encode()).hexdigest()[:20]


def generate_token(userId):
    return jwt.encode({'id': userId, 'exp': datetime.utcnow() + timedelta(minutes=30)}, app.config['SECRET_KEY'])


def parse_token(token):
    return jwt.decode(token, app.config['SECRET_KEY'], algorithms=["HS256"])


@app.route('/', methods=['GET'])
def route():
    response = redirect(url_for("login"))
    return response


@app.route('/dashboard', methods=['GET'])
@auth_required
def dashboard(token):
    user = db.getUserbyId(token["id"])
    if user["username"] == "admin":
        return render_template('dashboard.html', message=f"Your secret is: {open('flag.txt', 'r').read()}")
    return render_template('dashboard.html', message=f"lettuce")


@app.route('/register', methods=['POST'])
def register():
    username = request.form.get("username")
    password = request.form.get("password")

    hashed_password = ','.join([hash_char(c) for c in password])
    user = db.createUser(username, hashed_password)
    print(user)
    if user:
        response = redirect(url_for("dashboard"))
        response.set_cookie('authorization', generate_token(user["id"]))
        return response
    return render_template('login.html', error="Meeeeeh, something went wrong :(", action_name="register", button_name="Register")


@app.route('/login', methods=['GET'])
def login():
    return render_template('login.html', error="", action_name="login", button_name="Login")


@app.route('/login', methods=['POST'])
def login_user():
    username = request.form.get("username", None)
    password = request.form.get("password", None)

    if not username or not password:
        return jsonify({'message': 'login required'})

    user = db.getUserbyUsername(username)
    if user and check_password(username, user["password"], password):
        response = redirect(url_for("dashboard"))
        response.set_cookie('authorization', generate_token(user["id"]))
        return response

    return render_template('login.html', error="Meeeeeh, something went wrong :(", action_name="login", button_name="Login")


if __name__ == '__main__':
    password = open("password.txt", "r").read().strip()
    password = ','.join([hash_char(c) for c in password])
    user = db.createUser("admin", password)
    app.run(host="0.0.0.0")
