
const queryString = window.location.search;
const urlParams = new URLSearchParams(queryString);
const callback = urlParams.get('callback')
const shareId = urlParams.get('share_id')

function escape(data) {
    var nopes = ["`", "+", "<", ">", "'", '"', "%"]
    var x = data
    nopes.forEach(noperino => {
        x = x.replaceAll(noperino, '');
    });
    x = x.replaceAll(/script/ig, '');
    x = x.replaceAll(/iframe/ig, '');
    return x
}

var data = document.createElement('script');
src = '/get_style?share_id=' + shareId
if (callback) {
    var src = '/get_style?share_id=' + shareId + "&callback=" + escape(callback)
}

data.setAttribute('src', src);
document.head.appendChild(data);


function updateStyle(obj) {
    obj = escape(obj)
    var css = document.getElementById("customstyle")
    css.textContent = obj
}