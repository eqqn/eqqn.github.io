
const queryString = window.location.search;
const urlParams = new URLSearchParams(queryString);
const callback = urlParams.get('callback')

var data = document.createElement('script');
if (callback) {
    data.setAttribute('src', '/get_style?callback=' + escape(callback));
} else {
    data.setAttribute('src', '/get_style');
}
document.head.appendChild(data);

var sharestylebtn = document.getElementById("sharestylebtn")
sharestylebtn.addEventListener("click", share_style);

function escape(data) {
    var nopes = ["`", "+", "<", ">", "'", '"', "%"]
    var x = data
    nopes.forEach(noperino => {
        x = x.replaceAll(noperino, '');
    });
    x = x.replaceAll(/script/ig, '');
    x = x.replaceAll(/iframe/ig, '');
    return x
}

function updateStyle(obj) {
    obj = escape(obj)
    var sheet = document.createElement('style')
    sheet.textContent = obj;
    document.body.appendChild(sheet);
    var css = document.getElementById("customstyle")
    css.textContent = obj
}

function share_style(e) {
    e.preventDefault()
    var msg = document.getElementById("msg");
    var style = document.getElementById("customstyle").value

    var data = { style: style };

    fetch('/generate_link', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
    })
        .then((response) => response.json())
        .then((data) => {
            msg.innerHTML = data.message
        })
        .catch((error) => {
            console.error('Error:', error);
        });

}