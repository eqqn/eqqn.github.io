const puppeteer = require('puppeteer');
const fs = require('fs');
const url = require('url');

(async () => {
    const password = fs.readFileSync('password.txt').toString().trim();
    const browser = await puppeteer.launch({ headless: true, args: ['--no-sandbox', '--disable-gpu'] });
    const page = await browser.newPage();
    await page.goto('http://127.0.0.1:5000/login', { waitUntil: 'networkidle0' });
    await page.type('input[id=username]', 'admin');
    await page.type('input[id=password]', password);

    await Promise.all([
        page.click('#login_bttn'),
        page.waitForNavigation({ waitUntil: 'networkidle2' })
    ]);

    await page.goto('http://127.0.0.1:5000/dashboard', { waitUntil: 'networkidle0' });
    content = await page.content();
    if (!content.includes("Update your CSS")) {
        console.log("LOGIN FAILED");
        console.log(content);
        process.exit(0);
    }

    console.log("BOT SUCCESSFULLY LOGGED IN");
    let parsedUrl = "http://127.0.0.1:5000" + process.argv[2]
    console.log(parsedUrl)
    try {
        await page.goto(parsedUrl, { waitUntil: 'networkidle0' });
        await page.content();
    } catch (error) {
        console.log(error);
    }

    await browser.close();
})();