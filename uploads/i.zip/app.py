from flask import Flask, request, jsonify, redirect, url_for, render_template, current_app
import sqlite3
import jwt
from datetime import datetime, timedelta
from functools import wraps
import secrets
import hashlib
import binascii
import subprocess
import os

app = Flask(__name__)
app.config['SECRET_KEY'] = secrets.token_hex(20)
app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
)


class DB:

    db = sqlite3.connect("some.db", check_same_thread=False)
    cur = db.cursor()

    def __init__(self):
        create_table = """CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE,
            password TEXT NOT NULL,
            style TEXT NOT NULL
        );"""
        self.cur.execute(create_table)

        create_table = """CREATE TABLE IF NOT EXISTS styles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            style TEXT NOT NULL,
            share_id TEXT NOT NULL UNIQUE
        );"""
        self.cur.execute(create_table)

    def updateStyle(self, user_id, style):
        try:
            self.cur.execute(
                "UPDATE users SET style=? WHERE id=?", (style, user_id,))
            return True
        except Exception as e:
            print(e)
            return False

    def getStyleByShareId(self, share_id):
        return self.cur.execute("SELECT style FROM styles WHERE share_id=?", (share_id,)).fetchone()[0]

    def addShare(self, share_id, style):
        return self.cur.execute(
            "INSERT INTO styles VALUES(?,?,?)", (None, style, share_id,))

    def createUser(self, username, password, style):
        try:
            self.cur.execute("INSERT INTO users VALUES(?,?,?,?)",
                             (None, username, password, style))
            self.db.commit()
            return self.getUserbyUsername(username)
        except Exception as e:
            return None

    def getUserbyUsername(self, username):
        res = self.cur.execute(
            "SELECT id,username,password,style FROM users WHERE username=?", (username,))
        user = res.fetchone()
        if user:
            return {
                "id": user[0],
                "username": user[1],
                "password": user[2],
                "style": user[3],
            }
        return None

    def getUserbyId(self, id):
        res = self.cur.execute(
            "SELECT id,username,password,style FROM users WHERE id=?", (id,))
        user = res.fetchone()
        if user:
            return {
                "id": user[0],
                "username": user[1],
                "password": user[2],
                "style": user[3],
            }
        return None

    def checkPassword(self, username, password):
        return self.cur.execute(
            "SELECT username FROM users WHERE username=? AND password=?", (username, password)).fetchone()


db = DB()

DEFAULT_STYLE = """
body{
    background-color: white;
}
"""


def auth_required(f):
    @wraps(f)
    def decorator(*args, **kwargs):

        token = None
        if 'authorization' in request.cookies:
            token = request.cookies.get('authorization')

        if not token:
            return jsonify({'message': 'a valid token is missing'})
        try:
            data = jwt.decode(
                token, app.config['SECRET_KEY'], algorithms=["HS256"])
            current_user = db.getUserbyId(data["id"])
        except:
            return jsonify({'message': 'token is invalid'})

        return f(current_user, *args, **kwargs)
    return decorator


def check_password(username, password):
    password = hashlib.sha256(password.encode()).hexdigest()
    user = db.checkPassword(username, password)
    return user


def generate_token(userId):
    return jwt.encode({'id': userId, 'exp': datetime.utcnow() + timedelta(minutes=30)}, app.config['SECRET_KEY'])


def parse_token(token):
    return jwt.decode(token, app.config['SECRET_KEY'], algorithms=["HS256"])


@app.after_request
def apply_caching(response):
    response.headers["Content-Security-Policy"] = "script-src 'self' cdn.jsdelivr.net code.jquery.com;"
    return response


@app.route('/', methods=['GET'])
def route():
    response = redirect(url_for("login"))
    return response


@app.route('/bot', methods=['GET', 'POST'])
def bot():
    url = request.form.get("url", None)

    if request.method == "POST" and url:
        if "&&" in url or ";" in url or "|" in url or "(" in url or "{" in url:
            return "No free hats for you >:("
        if url.startswith("/share?"):
            subprocess.run(["node", "bot.js", url], shell=False)

    return render_template('bot.html')


@app.route('/gift_free_hat', methods=['POST'])
def free_hats():
    return "What are you doing?"


@app.route('/dashboard', methods=['GET'])
@auth_required
def dashboard(token):
    user = db.getUserbyId(token["id"])
    flag = open("flag.txt", "r").read().strip()
    if user["username"] != "admin":
        flag = "*" * len(flag)
    return render_template('dashboard.html', flag=flag)


@app.route('/update_style', methods=['POST'])
@auth_required
def update_style(token):
    style = request.form.get("style")
    print(style)
    db.updateStyle(token["id"], style)
    response = redirect(url_for("dashboard"))
    return response


@app.route('/get_style', methods=['GET'])
@auth_required
def get_style(token):
    share_id = request.args.get("share_id", None)
    callback = request.args.get('callback', 'updateStyle')
    if share_id:
        style = db.getStyleByShareId(share_id)
    else:
        user = db.getUserbyId(token["id"])
        style = user["style"]

    data = '{funcname}(`{data}`)'.format(
        funcname=callback,
        data=style,
    )
    return data, 200, {'Content-Type': 'application/javascript; charset=utf-8'}


@app.route('/share', methods=['GET'])
@auth_required
def get_share(token):
    user = db.getUserbyId(token["id"])
    flag = open("flag.txt", "r").read().strip()
    if user["username"] != "admin":
        flag = "*" * len(flag)
    return render_template('safeview.html', flag=flag)


@app.route('/generate_link', methods=['POST'])
@auth_required
def generate_link(share_id):
    style = request.json.get("style")
    share_id = binascii.b2a_hex(os.urandom(15)).decode()
    update = db.addShare(share_id, style)

    if update:
        return jsonify({"message": f"Awesome! Here's your link: <a href='/share?share_id={share_id}'>/share?share_id={share_id}</a>"})
    return jsonify({"message": f"Something went wrong..."})


@app.route('/register', methods=['GET'])
def register():
    return render_template('login.html', error="", action_name="register", button_name="Register")


@app.route('/login', methods=['GET'])
def login():
    return render_template('login.html', error="", action_name="login", button_name="Login")


@app.route('/register', methods=['POST'])
def register_user():
    username = request.form.get("username")
    password = request.form.get("password")
    password = hashlib.sha256(password.encode()).hexdigest()

    user = db.createUser(username, password, DEFAULT_STYLE)

    if user:
        response = redirect(url_for("dashboard"))
        response.set_cookie('authorization', generate_token(user["id"]))
        return response
    return render_template('login.html', error="Unable to create user", action_name="register", button_name="Register")


@app.route('/login', methods=['POST'])
def login_user():
    username = request.form.get("username", None)
    password = request.form.get("password", None)

    if not username or not password:
        return render_template('login.html', error="Unable to login", action_name="login", button_name="Login")

    user = db.getUserbyUsername(username)
    if check_password(username, password) and user:
        response = redirect(url_for("dashboard"))
        response.set_cookie('authorization', generate_token(user["id"]))
        return response

    return render_template('login.html', error="Unable to login", action_name="login", button_name="Login")


if __name__ == '__main__':
    password = open("password.txt", "r").read().strip()
    password = hashlib.sha256(password.encode()).hexdigest()
    db.createUser("admin", password, DEFAULT_STYLE)

    app.run(host="0.0.0.0", debug=True)
